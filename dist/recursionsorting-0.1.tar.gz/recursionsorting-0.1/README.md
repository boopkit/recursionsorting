# recursionsorting
This is a python package created for learning purposes and contains several recursive functions and commonly used sorting functions

## building package locally
`python setup.py sdist`

## installing package from GitHub
`pip install git+https://github.com/boopkit/recursionsorting.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/boopkit/recursionsorting.git`
